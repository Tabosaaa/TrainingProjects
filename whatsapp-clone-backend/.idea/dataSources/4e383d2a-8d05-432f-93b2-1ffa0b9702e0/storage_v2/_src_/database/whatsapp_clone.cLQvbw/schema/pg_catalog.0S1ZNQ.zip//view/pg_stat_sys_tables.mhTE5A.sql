create view pg_stat_sys_tables
            (relid, schemaname, relname, seq_scan, last_seq_scan, seq_tup_read, idx_scan, last_idx_scan, idx_tup_fetch,
             n_tup_ins, n_tup_upd, n_tup_del, n_tup_hot_upd, n_tup_newpage_upd, n_live_tup, n_dead_tup,
             n_mod_since_analyze, n_ins_since_vacuum, last_vacuum, last_autovacuum, last_analyze, last_autoanalyze,
             vacuum_count, autovacuum_count, analyze_count, autoanalyze_count)
as
SELECT relid,
       schemaname,
       relname,
       seq_scan,
       last_seq_scan,
       seq_tup_read,
       idx_scan,
       last_idx_scan,
       idx_tup_fetch,
       n_tup_ins,
       n_tup_upd,
       n_tup_del,
       n_tup_hot_upd,
       n_tup_newpage_upd,
       n_live_tup,
       n_dead_tup,
       n_mod_since_analyze,
       n_ins_since_vacuum,
       last_vacuum,
       last_autovacuum,
       last_analyze,
       last_autoanalyze,
       vacuum_count,
       autovacuum_count,
       analyze_count,
       autoanalyze_count
FROM pg_stat_all_tables
WHERE (schemaname = ANY (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
   OR schemaname ~ '^pg_toast'::text;

alter table pg_stat_sys_tables
    owner to username;

grant select on pg_stat_sys_tables to public;

